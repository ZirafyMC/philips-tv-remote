// --- Philips Smart TV Web Remote - Frontend Logic ---

// Elementos del DOM
const elStatusBadge = document.getElementById('status-badge');
const elStatusText = elStatusBadge.querySelector('.status-text');

// Tabs
const navTabs = document.querySelectorAll('.nav-tab');
const tabPanels = document.querySelectorAll('.tab-panel');

// Configuración Manual
const formConfig = document.getElementById('form-config');
const inputIp = document.getElementById('input-ip');
const selectVersion = document.getElementById('select-version');
const inputPort = document.getElementById('input-port');

// Escáner
const btnScan = document.getElementById('btn-scan');
const scanLoading = document.getElementById('scan-loading');
const scanResultsContainer = document.getElementById('scan-results-container');
const scanResultsList = document.getElementById('scan-results-list');
const scanBtnText = document.getElementById('scan-btn-text');

// Emparejamiento
const cardPairing = document.getElementById('card-pairing');
const btnRequestPairing = document.getElementById('btn-request-pairing');
const pairingStep1 = document.getElementById('pairing-step-1');
const pairingStep2 = document.getElementById('pairing-step-2');
const inputPin = document.getElementById('input-pin');
const btnSubmitPin = document.getElementById('btn-submit-pin');

// Teclado Numérico
const btnToggleNum = document.getElementById('btn-toggle-num');
const numericKeypad = document.getElementById('numeric-keypad');

// Ambilight
const btnAmbVideo = document.getElementById('amb-video');
const btnAmbAudio = document.getElementById('amb-audio');
const btnAmbOff = document.getElementById('amb-off');
const colorPresets = document.querySelectorAll('.preset-color');
const colorPickerInput = document.getElementById('color-picker-input');
const btnApplyColor = document.getElementById('btn-apply-color');

// Estado de la app
let appState = {
  ip: '',
  apiVersion: 6,
  port: 1926,
  configured: false,
  hasCredentials: false
};

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  checkStatus();
  initRemoteButtons();
  initSettingsListeners();
  initAmbilightListeners();
});

// Función de vibración haptica (feedback táctil)
function triggerHaptic() {
  if (navigator.vibrate) {
    navigator.vibrate(50);
  }
}

// Inicialización de pestañas
function initTabs() {
  navTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      triggerHaptic();
      const targetId = tab.getAttribute('data-target');
      
      navTabs.forEach(t => t.classList.remove('active'));
      tabPanels.forEach(p => p.classList.remove('active'));
      
      tab.classList.add('active');
      document.getElementById(targetId).classList.add('active');
    });
  });
}

// Navegar programáticamente a una pestaña
function navigateToTab(tabId) {
  const tab = Array.from(navTabs).find(t => t.getAttribute('data-target') === tabId);
  if (tab) {
    tab.click();
  }
}

// Comprobar estado de configuración actual del backend
async function checkStatus() {
  try {
    const res = await fetch('/api/status');
    const status = await res.json();
    
    appState = status;
    updateStatusUI();
    
    if (status.configured) {
      inputIp.value = status.ip;
      selectVersion.value = status.apiVersion;
      inputPort.value = status.port;
    } else {
      // Si no está configurado, abrimos la pestaña de Ajustes
      navigateToTab('tab-settings');
    }
  } catch (err) {
    console.error('Error al comprobar estado:', err);
    updateStatusIndicator('disconnected', 'Error de red');
  }
}

// Actualizar la barra de estado y la interfaz según la configuración
function updateStatusUI() {
  if (!appState.configured) {
    updateStatusIndicator('disconnected', 'Sin configurar');
    cardPairing.classList.add('hidden');
    return;
  }

  // Si requiere autenticación (pairing)
  if (appState.authRequired) {
    if (appState.hasCredentials) {
      updateStatusIndicator('connected', `Conectado (v${appState.apiVersion})`);
      cardPairing.classList.add('hidden');
    } else {
      updateStatusIndicator('pairing', 'Emparejar TV');
      cardPairing.classList.remove('hidden');
      resetPairingUI();
    }
  } else {
    // Si no requiere autenticación (API v1 o v6 híbrido sin emparejamiento)
    updateStatusIndicator('connected', `Conectado (v${appState.apiVersion})`);
    cardPairing.classList.add('hidden');
  }
}

function updateStatusIndicator(stateClass, text) {
  elStatusBadge.className = `status-badge ${stateClass}`;
  elStatusText.textContent = text;
}

function resetPairingUI() {
  pairingStep1.classList.remove('hidden');
  pairingStep2.classList.add('hidden');
  inputPin.value = '';
}

// Inicializar botones del control remoto
function initRemoteButtons() {
  // Listeners para todos los botones que emulan teclas físicas de la TV
  document.querySelectorAll('[data-key]').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      triggerHaptic();
      
      // Manejador específico para el botón de teclado
      if (btn.id === 'btn-toggle-num') {
        toggleNumericKeypad();
        return;
      }
      
      const key = btn.getAttribute('data-key');
      
      // Indicar visualmente que se presionó (si es una tecla de color o pill)
      btn.classList.add('pressed');
      setTimeout(() => btn.classList.remove('pressed'), 200);

      try {
        const res = await fetch('/api/command', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ key })
        });
        const data = await res.json();
        if (data.error) {
          console.warn('TV respondió con error:', data.error);
        }
      } catch (err) {
        console.error('Error al enviar comando:', err);
      }
    });
  });
}

// Alternar el keypad numérico
function toggleNumericKeypad() {
  btnToggleNum.classList.toggle('active');
  numericKeypad.classList.toggle('hidden');
}

// Inicializar lógica de Configuración y Escaneo
function initSettingsListeners() {
  // Guardar configuración manual
  formConfig.addEventListener('submit', async (e) => {
    e.preventDefault();
    triggerHaptic();

    const ip = inputIp.value.trim();
    const apiVersion = parseInt(selectVersion.value);
    const port = parseInt(inputPort.value);

    await connectToTv(ip, port, apiVersion);
  });

  // Ajustar puerto automáticamente según versión de API seleccionada
  selectVersion.addEventListener('change', () => {
    if (selectVersion.value === '6') {
      inputPort.value = '1926';
    } else {
      inputPort.value = '1925';
    }
  });

  // Escaneo de red
  btnScan.addEventListener('click', async () => {
    triggerHaptic();
    btnScan.disabled = true;
    scanBtnText.textContent = "Buscando...";
    btnScan.querySelector('svg').classList.add('icon-spin');
    scanLoading.classList.remove('hidden');
    scanResultsContainer.classList.add('hidden');
    scanResultsList.innerHTML = '';

    try {
      const res = await fetch('/api/scan');
      const data = await res.json();
      
      scanLoading.classList.add('hidden');
      btnScan.disabled = false;
      scanBtnText.textContent = "Buscar en mi red";
      btnScan.querySelector('svg').classList.remove('icon-spin');

      if (data.tvs && data.tvs.length > 0) {
        data.tvs.forEach(tv => {
          const li = document.createElement('li');
          li.className = 'device-item';
          li.innerHTML = `
            <div class="device-info">
              <span class="device-name">${tv.name}</span>
              <span class="device-ip">${tv.ip}:${tv.port}</span>
            </div>
            <span class="device-badge ${tv.apiVersion === 1 ? 'v1' : ''}">API v${tv.apiVersion}</span>
          `;
          
          li.addEventListener('click', async () => {
            triggerHaptic();
            inputIp.value = tv.ip;
            selectVersion.value = tv.apiVersion;
            inputPort.value = tv.port;
            await connectToTv(tv.ip, tv.port, tv.apiVersion);
          });

          scanResultsList.appendChild(li);
        });
        scanResultsContainer.classList.remove('hidden');
      } else {
        alert('No se encontraron televisores Philips encendidos en la red local. Verifica que tu celular/computadora comparta el mismo Wi-Fi que la televisión.');
      }
    } catch (err) {
      console.error(err);
      alert('Ocurrió un error al buscar en la red: ' + err.message);
      scanLoading.classList.add('hidden');
      btnScan.disabled = false;
      scanBtnText.textContent = "Buscar en mi red";
      btnScan.querySelector('svg').classList.remove('icon-spin');
    }
  });

  // Solicitar emparejamiento (PIN en pantalla)
  btnRequestPairing.addEventListener('click', async () => {
    triggerHaptic();
    try {
      const res = await fetch('/api/pair/request', { method: 'POST' });
      const data = await res.json();
      
      if (data.success) {
        pairingStep1.classList.add('hidden');
        pairingStep2.classList.remove('hidden');
        alert(data.message);
      } else {
        alert('Error: ' + data.error);
      }
    } catch (err) {
      alert('Error de red al solicitar emparejamiento: ' + err.message);
    }
  });

  // Enviar el PIN
  btnSubmitPin.addEventListener('click', async () => {
    triggerHaptic();
    const pin = inputPin.value.trim();
    if (!pin || pin.length !== 4) {
      alert('Ingresa el código PIN de 4 dígitos');
      return;
    }

    try {
      const res = await fetch('/api/pair/grant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      const data = await res.json();
      
      if (data.success) {
        alert(data.message);
        await checkStatus(); // Refrescar el estado
        navigateToTab('tab-control'); // Ir al mando a distancia
      } else {
        alert('Error: ' + data.error);
      }
    } catch (err) {
      alert('Error de conexión al enviar el PIN: ' + err.message);
    }
  });
}

// Helper para conectar a una TV
async function connectToTv(ip, port, apiVersion) {
  try {
    const res = await fetch('/api/connect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ip, port, apiVersion })
    });
    const data = await res.json();

    if (data.success) {
      await checkStatus();
      if (data.paired) {
        alert(data.message);
        navigateToTab('tab-control');
      } else {
        alert('La TV requiere emparejamiento. Completa el PIN de 4 dígitos abajo.');
        navigateToTab('tab-settings');
      }
    } else {
      alert('No se pudo conectar: ' + data.error);
    }
  } catch (err) {
    alert('Error al intentar conectar: ' + err.message);
  }
}

// Inicializar controles de Ambilight
function initAmbilightListeners() {
  
  // Cambios de modo de Ambilight
  btnAmbVideo.addEventListener('click', () => {
    setAmbilightMode({ styleName: 'FOLLOW_VIDEO' });
    setActiveAmbModeButton(btnAmbVideo);
  });

  btnAmbAudio.addEventListener('click', () => {
    setAmbilightMode({ styleName: 'FOLLOW_AUDIO' });
    setActiveAmbModeButton(btnAmbAudio);
  });

  btnAmbOff.addEventListener('click', () => {
    setAmbilightMode({ styleName: 'OFF' });
    setActiveAmbModeButton(btnAmbOff);
  });

  // Presets de color estático
  colorPresets.forEach(preset => {
    preset.addEventListener('click', async () => {
      triggerHaptic();
      const r = parseInt(preset.getAttribute('data-r'));
      const g = parseInt(preset.getAttribute('data-g'));
      const b = parseInt(preset.getAttribute('data-b'));
      
      // Aplicar modo manual primero, y luego fijar el color
      await setAmbilightMode({ current: 'manual' });
      await setAmbilightColor(r, g, b);
      setActiveAmbModeButton(null); // Desactivar botones de video/audio
    });
  });

  // Color picker personalizado
  btnApplyColor.addEventListener('click', async () => {
    triggerHaptic();
    const hex = colorPickerInput.value;
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);

    await setAmbilightMode({ current: 'manual' });
    await setAmbilightColor(r, g, b);
    setActiveAmbModeButton(null);
  });
}

function setActiveAmbModeButton(activeBtn) {
  btnAmbVideo.classList.remove('active');
  btnAmbAudio.classList.remove('active');
  btnAmbOff.classList.remove('active');
  if (activeBtn) activeBtn.classList.add('active');
}

async function setAmbilightMode(modePayload) {
  triggerHaptic();
  try {
    const res = await fetch('/api/ambilight/mode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(modePayload)
    });
    return await res.json();
  } catch (err) {
    console.error('Error al cambiar modo Ambilight:', err);
  }
}

async function setAmbilightColor(r, g, b) {
  try {
    const res = await fetch('/api/ambilight/color', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ r, g, b })
    });
    return await res.json();
  } catch (err) {
    console.error('Error al cambiar color Ambilight:', err);
  }
}
